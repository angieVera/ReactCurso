import React, { Fragment, useState, useEffect } from 'react';
import Formulario from './componentes/Formulario.js';
import Cita from './componentes/Cita.js';


function App() {
//citas en local storage
let  citasIniciales =JSON.parse(localStorage.getItem('citas'));

if(!citasIniciales){
  citasIniciales =[];
}

  //arreglo de citas
  const [citas, guardarCitas] = useState(citasIniciales);

  //useEffect para realizar operacion cuando el state cambi
  useEffect ( () =>{
    //console.log('Documento listo o paso algo con la cita');
    if(citasIniciales){
      localStorage.setItem('citas' , JSON.stringify(citas))
    }else{
      localStorage.setItem('citas', JSON.stringify([]));
    }
  }, [citas, citasIniciales]);

  //funcion que tome las citas actuales y agregue la nueva
  const crearCita = cita => {
    guardarCitas(
      [
        ...citas,
        cita
      ]
    );
  }

  //aca ponermos el mensaje condicional
  // console.log(citas.length);
  const Titulo = citas.length === 0 ? 'no hay citas' : 'Porfa administra tus citas';


  //esta es una funcion q elimina la cita por su id

  const eliminarCita =id =>{
    const nuevasCitas = citas.filter(cita => cita.id !== id);
    guardarCitas(nuevasCitas);
  }

  //aca mensaje condicional, es bueno colocar estandar andes del return

  //console.log(citas.length);

const titulo =citas.length === 0     ?'No hay citas'    : 'Administra tu cita';




  return (
    <Fragment>

      <h1>Administrador de pacientes</h1>

      <div className="container">
        <div className="row">
          <div className="one-half column">
            <Formulario
              crearCita={crearCita}

            />
          </div>
          <div className='one-half column'>
            <h2>
              {Titulo}

            </h2>
            {citas.map(cita => (
              <Cita
                key={cita.id}
                cita={cita}
                eliminarCita={eliminarCita}
              />
            ))}
          </div>
        </div>
      </div>
    </Fragment>
  );
}

export default App;
