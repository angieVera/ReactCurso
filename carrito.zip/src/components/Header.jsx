import React from 'react';

//aca abrimos una funcion, este es la forma correcta
function Header({titulo}) {
   

    return(
        <h1  className="encabezado"> 
           {titulo}
        </h1>
    )

}

export default Header;

